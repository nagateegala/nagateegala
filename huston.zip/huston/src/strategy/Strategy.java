package strategy;

interface Strategy { public void solve(); }          // 1. Define the interface
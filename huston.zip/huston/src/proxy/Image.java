package proxy;

interface Image {
    public void displayImage();
}
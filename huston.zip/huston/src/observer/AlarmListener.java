package observer;

interface AlarmListener { public void alarm(); }
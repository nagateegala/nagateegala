package command;

interface Command {
        public void execute ( );
}
package decorator;

interface Widget { void draw(); }             // 1. "lowest common denominator"
package bridge;

class StackJava extends java.util.Stack implements StackImp { }
package bridge;

interface StackImp {           // 1. Create an implementation/body base class
   Object  push( Object o );   Object  peek();
   boolean empty();            Object  pop(); }
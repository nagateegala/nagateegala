package prototype;

interface Prototype { Object clone();   String getName(); }  // 1. The clone()
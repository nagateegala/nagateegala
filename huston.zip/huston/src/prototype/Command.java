package prototype;

interface Command   { void   execute(); }                    //    contract
package factory;

class ConcreteProductA implements Product{
  public String getName() {
    return "ProductA";
  }
}
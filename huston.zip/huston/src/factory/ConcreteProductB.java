package factory;

class ConcreteProductB implements Product {
  public String getName() {
    return "ProductB";
  }
}
package factory;

interface Product {
  public String getName();
}
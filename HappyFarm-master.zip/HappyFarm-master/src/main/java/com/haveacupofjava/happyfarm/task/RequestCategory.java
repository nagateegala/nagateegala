package com.haveacupofjava.happyfarm.task;

public enum RequestCategory {
    PEN_REQUEST, FARM_REQUEST
}

package com.haveacupofjava.happyfarm.task;

public class DuplicateRequestParsingRuleException extends Exception {

    public DuplicateRequestParsingRuleException(String message) {
        super(message);
    }

}

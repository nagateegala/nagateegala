package com.haveacupofjava.happyfarm.task;

public class RequestParsingException extends Exception {

    public RequestParsingException(String message) {
        super(message);
    }

}

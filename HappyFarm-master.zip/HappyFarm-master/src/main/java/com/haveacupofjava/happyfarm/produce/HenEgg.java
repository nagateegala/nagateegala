package com.haveacupofjava.happyfarm.produce;

public class HenEgg extends AbstractEggProduce {

    public HenEgg() {
        setName("HenEgg");
        setPrice(1.0);
    }

}

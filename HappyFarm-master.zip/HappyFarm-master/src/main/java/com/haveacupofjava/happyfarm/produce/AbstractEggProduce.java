package com.haveacupofjava.happyfarm.produce;

public class AbstractEggProduce extends AbstractProduce {
}

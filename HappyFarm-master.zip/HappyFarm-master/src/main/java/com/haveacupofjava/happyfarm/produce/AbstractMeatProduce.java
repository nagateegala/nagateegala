package com.haveacupofjava.happyfarm.produce;

public abstract class AbstractMeatProduce extends AbstractProduce {
}

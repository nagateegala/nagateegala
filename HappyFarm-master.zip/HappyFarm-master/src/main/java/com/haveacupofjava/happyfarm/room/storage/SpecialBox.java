package com.haveacupofjava.happyfarm.room.storage;


public abstract class SpecialBox extends AbstractBox {
}

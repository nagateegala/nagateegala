package com.haveacupofjava.happyfarm.field;

import java.io.Serializable;

/**
  * Class AbstractFieldComponent
  * Description
  */
public abstract class AbstractFieldComponent implements Serializable {

    public abstract void show();

}

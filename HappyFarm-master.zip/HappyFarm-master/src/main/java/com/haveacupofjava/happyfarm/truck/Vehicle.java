package com.haveacupofjava.happyfarm.truck;

public interface Vehicle {

    void startVehicle();

    void stopVehicle();

    void brakeVehicle();

}

package com.haveacupofjava.happyfarm.security;

public class MethodExposedException extends Exception {

    public MethodExposedException(String message) {
        super(message);
    }

}

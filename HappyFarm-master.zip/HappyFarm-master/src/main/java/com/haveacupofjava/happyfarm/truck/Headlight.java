package com.haveacupofjava.happyfarm.truck;

public interface Headlight {

    void lightHeadlight();

}

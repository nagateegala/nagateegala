package com.haveacupofjava.happyfarm;

public class MementoSettingException extends Exception {

    public MementoSettingException(String message) {
        super(message);
    }

}

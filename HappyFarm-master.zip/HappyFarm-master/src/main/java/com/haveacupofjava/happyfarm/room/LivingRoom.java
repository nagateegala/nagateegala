package com.haveacupofjava.happyfarm.room;

public class LivingRoom extends AbstractRoom {

    public LivingRoom() {
        setName("livingRoom");
    }

    @Override
    public void clean(String action) {
        super.clean(action);
    }

}

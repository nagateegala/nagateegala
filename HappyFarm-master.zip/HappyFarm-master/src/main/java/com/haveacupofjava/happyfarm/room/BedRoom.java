package com.haveacupofjava.happyfarm.room;

public class BedRoom extends AbstractRoom {

    public BedRoom() {
        setName("bedRoom");
    }

    @Override
    public void clean(String action) {
        super.clean(action);
    }

}

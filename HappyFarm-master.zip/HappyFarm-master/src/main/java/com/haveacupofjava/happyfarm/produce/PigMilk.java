package com.haveacupofjava.happyfarm.produce;

/**
  * Class PigMilk
  * Produced by pig
  */
public class PigMilk extends AbstractMilkProduce {

    public PigMilk() {
        setName("PigMilk");
        setPrice(1.0);
    }

}

package com.haveacupofjava.happyfarm.product;

public abstract class AbstractFurniture extends AbstractProduct {
}

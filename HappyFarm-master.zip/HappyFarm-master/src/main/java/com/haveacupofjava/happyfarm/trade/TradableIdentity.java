package com.haveacupofjava.happyfarm.trade;

public enum TradableIdentity {

    BUYER, SELLER, BOTH_BUYER_AND_SELLER

}

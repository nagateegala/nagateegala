package com.haveacupofjava.happyfarm.room;

public class KitchenRoom extends AbstractRoom {

    public KitchenRoom() {
        setName("kitchenRoom");
    }

    @Override
    public void clean(String action) {
        super.clean(action);
    }

}

package com.haveacupofjava.happyfarm.room;

public interface Cleanable {

    /**
     * Used to clean and need to implements
     */
    void clean();

}

package com.haveacupofjava.happyfarm.trade;

public interface Tradable {

    TradableIdentity identity = TradableIdentity.BUYER;

}

package com.haveacupofjava.happyfarm.truck;

public interface Horn {

    void blareHorn();

}

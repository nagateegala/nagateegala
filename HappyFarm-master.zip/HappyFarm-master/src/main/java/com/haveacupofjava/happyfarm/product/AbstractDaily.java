package com.haveacupofjava.happyfarm.product;

public abstract class AbstractDaily extends AbstractProduct {
}

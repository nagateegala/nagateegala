package com.haveacupofjava.happyfarm.produce;

public abstract class AbstractFruitProduce extends AbstractProduce {
}
